--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8 (Debian 13.8-1.pgdg110+1)
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE assignment;
--
-- Name: assignment; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE assignment WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE assignment OWNER TO root;

\connect assignment

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: root
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO root;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: root
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: products; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.products (
    product_id integer,
    product_name character varying(64),
    price real,
    avg_days_to_replenish integer,
    expiration_date character varying(16),
    brand character varying(16),
    description character varying(128)
);


ALTER TABLE public.products OWNER TO root;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sales (
    order_id bigint,
    product_id integer,
    quantity_sold integer,
    date_sold date,
    customer_name character varying(32),
    customer_address character varying(32)
);


ALTER TABLE public.sales OWNER TO root;

--
-- Name: sales_lastday; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sales_lastday (
    order_id integer,
    product_id integer,
    quantity_sold integer,
    date_sold character varying(16),
    customer_name character varying(32),
    customer_address character varying(32)
);


ALTER TABLE public.sales_lastday OWNER TO root;

--
-- Name: stock; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.stock (
    stock_id bigint,
    product_id integer,
    status character varying(8),
    amount integer,
    date date
);


ALTER TABLE public.stock OWNER TO root;

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.products (product_id, product_name, price, avg_days_to_replenish, expiration_date, brand, description) FROM stdin;
\.
COPY public.products (product_id, product_name, price, avg_days_to_replenish, expiration_date, brand, description) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.sales (order_id, product_id, quantity_sold, date_sold, customer_name, customer_address) FROM stdin;
\.
COPY public.sales (order_id, product_id, quantity_sold, date_sold, customer_name, customer_address) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: sales_lastday; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.sales_lastday (order_id, product_id, quantity_sold, date_sold, customer_name, customer_address) FROM stdin;
\.
COPY public.sales_lastday (order_id, product_id, quantity_sold, date_sold, customer_name, customer_address) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.stock (stock_id, product_id, status, amount, date) FROM stdin;
\.
COPY public.stock (stock_id, product_id, status, amount, date) FROM '$$PATH$$/2995.dat';

--
-- PostgreSQL database dump complete
--

